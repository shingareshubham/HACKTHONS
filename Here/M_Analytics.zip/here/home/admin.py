from django.contrib import admin
from .models import register_case

# Register your models here.

admin.site.register(register_case)