from django.apps import AppConfig


class ModelingConfig(AppConfig):
    name = 'modeling'
