from django.contrib import admin
from .models import titanic

# Register your models here.

admin.site.register(titanic)